const express = require("express");
const app = express();

app.get("/", function (request, response) {
  response.send("Hello I am Working!");
});
app.listen(3000, function () {
  console.log(
    "Server is running and listening to port 3000.Open https://localhost:3000 to get your service"
  );
});
