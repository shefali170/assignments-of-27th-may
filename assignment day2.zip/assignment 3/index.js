const express = require("express");

const app = express();

app.use(express.urlencoded({ extended: true }));

app.get("/", function (request, response) {
  response.sendFile(__dirname + "/index.html");
});

app.post("/", function (request, response) {
  response.send(
    "Welcome" + request.body.firstName + "" + request.body.secondName
  );
});

app.get("/contact", function (request, response) {
  response.sendFile(__dirname + "/contact.html");
});

app.listen(3000, function () {
  console.log(
    "Server is running and listening to port 3000.Open https://localhost:3000 to get your service"
  );
});
